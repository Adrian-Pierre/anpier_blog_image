#pragma once

#include <stdint.h>
#include "esp_log.h"
#include "esp_err.h"
#include "led_strip.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    led_strip_handle_t strip;
    int gpio;
} board_rgb_t;

/**
 * @brief 初始化板载 WS2812B（默认 1 颗 LED）
 * @param dev 句柄
 * @param gpio WS2812 数据引脚 GPIO
 */
esp_err_t board_rgb_init(board_rgb_t *dev, int gpio);

/**
 * @brief 设置颜色（RGB: 0~255），内部会 refresh
 */
esp_err_t board_rgb_set(board_rgb_t *dev, uint8_t r, uint8_t g, uint8_t b);

/**
 * @brief 关闭（清除并 refresh）
 */
esp_err_t board_rgb_off(board_rgb_t *dev);

#ifdef __cplusplus
}
#endif
