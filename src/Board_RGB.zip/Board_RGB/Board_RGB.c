#include "board_rgb.h"
#include "esp_log.h"
#include "esp_err.h"
#include "driver/rmt_types.h" 

static const char *TAG = "board_rgb";

#define BOARD_RGB_RMT_RES_HZ (10 * 1000 * 1000)

#define BOARD_RGB_LED_COUNT  (1)

#define BOARD_RGB_USE_DMA    (0)

esp_err_t board_rgb_init(board_rgb_t *dev, int gpio)
{
    if (!dev) return ESP_ERR_INVALID_ARG;

    led_strip_config_t strip_config = {
        .strip_gpio_num = gpio,
        .max_leds = BOARD_RGB_LED_COUNT,
        .led_model = LED_MODEL_WS2812,
        .color_component_format = LED_STRIP_COLOR_COMPONENT_FMT_GRB,
        .flags = {
            .invert_out = false,
        }
    };

    led_strip_rmt_config_t rmt_config = {
        .clk_src = RMT_CLK_SRC_DEFAULT,
        .resolution_hz = BOARD_RGB_RMT_RES_HZ,
        .mem_block_symbols = 0, // 让驱动自动选
        .flags = {
            .with_dma = BOARD_RGB_USE_DMA,
        }
    };

    dev->gpio = gpio;
    dev->strip = NULL;

    esp_err_t ret = led_strip_new_rmt_device(&strip_config, &rmt_config, &dev->strip);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "led_strip_new_rmt_device failed: %s", esp_err_to_name(ret));
        return ret;
    }

    (void)led_strip_clear(dev->strip);
    (void)led_strip_refresh(dev->strip);

    ESP_LOGI(TAG, "board rgb init ok on GPIO %d", gpio);
    return ESP_OK;
}

esp_err_t board_rgb_set(board_rgb_t *dev, uint8_t r, uint8_t g, uint8_t b)
{
    if (!dev || !dev->strip) return ESP_ERR_INVALID_STATE;

    esp_err_t ret = led_strip_set_pixel(dev->strip, 0, r, g, b);
    if (ret != ESP_OK) return ret;

    return led_strip_refresh(dev->strip);
}

esp_err_t board_rgb_off(board_rgb_t *dev)
{
    if (!dev || !dev->strip) return ESP_ERR_INVALID_STATE;

    esp_err_t ret = led_strip_clear(dev->strip);
    if (ret != ESP_OK) return ret;

    return led_strip_refresh(dev->strip);
}
