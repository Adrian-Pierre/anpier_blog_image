#pragma once

#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int trig_gpio;
    int echo_gpio;
    float sound_speed_m_s;   // 默认 343.0f（约 20~25°C）
    uint32_t timeout_us;     // 默认 30000us（约 5m 上限，避免死等）
} hcsr04_config_t;

/**
 * @brief 初始化 HC-SR04（配置 TRIG 输出、ECHO 输入）
 */
esp_err_t hcsr04_init(const hcsr04_config_t *cfg);

/**
 * @brief 读取距离（毫米）。成功返回 ESP_OK，distance_mm 输出测距值。
 */
esp_err_t hcsr04_read_mm(int16_t *distance_mm);

/**
 * @brief 读取距离（米，float）。成功返回 ESP_OK，distance_m 输出测距值。
 */
esp_err_t hcsr04_read_m(float *distance_m);

/**
 * @brief 工具：计算整数位数（你原来 numlen 的等价实现）
 */
uint64_t hcsr04_numlen(uint64_t num);

#ifdef __cplusplus
}
#endif
