#include "hcsr04.h"

#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "esp_rom_sys.h"   // esp_rom_delay_us
#include "esp_check.h"

static const char *TAG = "hcsr04";

static hcsr04_config_t s_cfg;
static bool s_inited = false;

static inline int64_t now_us(void) { return esp_timer_get_time(); }

static esp_err_t wait_level(gpio_num_t pin, int level, uint32_t timeout_us)
{
    int64_t t0 = now_us();
    while (gpio_get_level(pin) != level) {
        if ((uint32_t)(now_us() - t0) > timeout_us) {
            return ESP_ERR_TIMEOUT;
        }
    }
    return ESP_OK;
}

esp_err_t hcsr04_init(const hcsr04_config_t *cfg)
{
    if (!cfg) return ESP_ERR_INVALID_ARG;

    s_cfg = *cfg;
    if (s_cfg.sound_speed_m_s <= 0) s_cfg.sound_speed_m_s = 343.0f;
    if (s_cfg.timeout_us == 0)      s_cfg.timeout_us = 30000; // 30ms

    gpio_config_t io = {0};

    // TRIG 输出
    io.pin_bit_mask = 1ULL << s_cfg.trig_gpio;
    io.mode = GPIO_MODE_OUTPUT;
    io.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io.pull_up_en = GPIO_PULLUP_DISABLE;
    io.intr_type = GPIO_INTR_DISABLE;
    ESP_ERROR_CHECK(gpio_config(&io));
    gpio_set_level((gpio_num_t)s_cfg.trig_gpio, 0);

    // ECHO 输入（默认下拉，避免悬空）
    io.pin_bit_mask = 1ULL << s_cfg.echo_gpio;
    io.mode = GPIO_MODE_INPUT;
    io.pull_down_en = GPIO_PULLDOWN_ENABLE;
    io.pull_up_en = GPIO_PULLUP_DISABLE;
    io.intr_type = GPIO_INTR_DISABLE;
    ESP_ERROR_CHECK(gpio_config(&io));

    s_inited = true;

    ESP_LOGI(TAG, "init ok (TRIG=%d ECHO=%d speed=%.1fm/s timeout=%uus)",
             s_cfg.trig_gpio, s_cfg.echo_gpio, s_cfg.sound_speed_m_s, s_cfg.timeout_us);

    return ESP_OK;
}

static esp_err_t measure_pulse_us(uint32_t *pulse_us)
{
    if (!s_inited || !pulse_us) return ESP_ERR_INVALID_STATE;

    gpio_num_t trig = (gpio_num_t)s_cfg.trig_gpio;
    gpio_num_t echo = (gpio_num_t)s_cfg.echo_gpio;

    // 触发：高电平 >=10us
    gpio_set_level(trig, 0);
    esp_rom_delay_us(2);
    gpio_set_level(trig, 1);
    esp_rom_delay_us(12);
    gpio_set_level(trig, 0);

    // 等待 ECHO 拉高（开始）
    ESP_RETURN_ON_ERROR(wait_level(echo, 1, s_cfg.timeout_us), TAG, "wait echo high timeout");

    int64_t t_start = now_us();

    // 等待 ECHO 拉低（结束）
    ESP_RETURN_ON_ERROR(wait_level(echo, 0, s_cfg.timeout_us), TAG, "wait echo low timeout");

    int64_t t_end = now_us();
    int64_t dt = t_end - t_start;
    if (dt <= 0) return ESP_ERR_INVALID_RESPONSE;

    *pulse_us = (uint32_t)dt;
    return ESP_OK;
}

esp_err_t hcsr04_read_mm(int16_t *distance_mm)
{
    if (!distance_mm) return ESP_ERR_INVALID_ARG;

    uint32_t pulse_us = 0;
    esp_err_t err = measure_pulse_us(&pulse_us);
    if (err != ESP_OK) return err;

    // 距离 = 时间 * 声速 / 2
    // pulse_us(微秒) -> 秒：pulse_us * 1e-6
    // 距离(米) = pulse_us * 1e-6 * v / 2
    // 距离(毫米) = 上式 * 1000
    float mm = (pulse_us * 1e-6f) * s_cfg.sound_speed_m_s * 1000.0f * 0.5f;

    if (mm < 0) mm = 0;
    if (mm > 32767) mm = 32767;

    *distance_mm = (int16_t)(mm + 0.5f);
    return ESP_OK;
}

esp_err_t hcsr04_read_m(float *distance_m)
{
    if (!distance_m) return ESP_ERR_INVALID_ARG;

    int16_t mm = 0;
    esp_err_t err = hcsr04_read_mm(&mm);
    if (err != ESP_OK) return err;

    *distance_m = (float)mm / 1000.0f;
    return ESP_OK;
}

uint64_t hcsr04_numlen(uint64_t num)
{
    uint64_t len = 1;
    while (num > 9) {
        num /= 10;
        ++len;
    }
    return len;
}
