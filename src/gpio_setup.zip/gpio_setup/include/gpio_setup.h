#pragma once

#include <stdbool.h>
#include <stddef.h>
#include "esp_err.h"
#include "driver/gpio.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 单个 GPIO 的初始化配置项（只做配置，不做 ISR/任务/回调）
 */
typedef struct {
    gpio_num_t      gpio_num;      /*!< GPIO 编号 */
    gpio_mode_t     mode;          /*!< GPIO 模式：输入/输出/开漏等 */
    bool            pull_up_en;    /*!< 启用内部上拉 */
    bool            pull_down_en;  /*!< 启用内部下拉 */

    int             level;         /*!< 输出模式下的初始电平(0/1)，输入模式忽略 */

    gpio_int_type_t intr_type;     /*!< 中断类型：默认 GPIO_INTR_DISABLE（仅配置寄存器，不安装 ISR 服务） */
} gpio_config_item_t;

/**
 * @brief GPIO 配置项的推荐初始化宏（更不容易漏字段）
 */
#define GPIO_CONFIG_ITEM_DEFAULT() {            \
    .gpio_num = GPIO_NUM_NC,                    \
    .mode = GPIO_MODE_DISABLE,                  \
    .pull_up_en = false,                        \
    .pull_down_en = false,                      \
    .level = 0,                                 \
    .intr_type = GPIO_INTR_DISABLE,             \
}

/**
 * @brief 初始化一组 GPIO 引脚
 *
 * @param[in] config_array  gpio_config_item_t 数组
 * @param[in] array_size    数组元素数量
 *
 * @return ESP_OK 成功；否则返回对应错误码（遇到第一处错误即返回）
 */
esp_err_t gpio_setup_init(const gpio_config_item_t *config_array, size_t array_size);

#ifdef __cplusplus
}
#endif
