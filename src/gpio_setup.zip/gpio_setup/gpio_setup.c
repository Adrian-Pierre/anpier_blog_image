#include "gpio_setup.h"

#include <inttypes.h>
#include "esp_log.h"
#include "esp_check.h"

static const char *TAG = "gpio_setup";

static const char *mode_to_str(gpio_mode_t mode)
{
    if (mode == GPIO_MODE_INPUT) return "INPUT";
    if (mode == GPIO_MODE_OUTPUT) return "OUTPUT";
    if (mode == GPIO_MODE_INPUT_OUTPUT) return "INOUT";
    if (mode == GPIO_MODE_OUTPUT_OD) return "OUTPUT_OD";
    if (mode == GPIO_MODE_INPUT_OUTPUT_OD) return "INOUT_OD";
    if (mode == GPIO_MODE_DISABLE) return "DISABLE";
    return "UNKNOWN";
}

static bool is_valid_gpio(gpio_num_t gpio_num)
{
    // GPIO_NUM_NC 通常用于“无效/未连接”，这里直接判 invalid
    if (gpio_num == GPIO_NUM_NC) return false;
    return gpio_num >= 0 && gpio_num < GPIO_NUM_MAX;
}

esp_err_t gpio_setup_init(const gpio_config_item_t *config_array, size_t array_size)
{
    ESP_RETURN_ON_FALSE(config_array != NULL, ESP_ERR_INVALID_ARG, TAG, "config_array is NULL");
    ESP_RETURN_ON_FALSE(array_size > 0, ESP_ERR_INVALID_ARG, TAG, "array_size is 0");

    for (size_t i = 0; i < array_size; i++) {
        const gpio_config_item_t *item = &config_array[i];

        ESP_RETURN_ON_FALSE(is_valid_gpio(item->gpio_num),
                            ESP_ERR_INVALID_ARG, TAG,
                            "invalid gpio_num at index=%u (gpio=%d)",
                            (unsigned)i, (int)item->gpio_num);

        // 输出初始电平只接受 0/1（更严格）
        if ((item->mode & GPIO_MODE_OUTPUT) != 0) {
            ESP_RETURN_ON_FALSE(item->level == 0 || item->level == 1,
                                ESP_ERR_INVALID_ARG, TAG,
                                "invalid level at index=%u (gpio=%d, level=%d)",
                                (unsigned)i, (int)item->gpio_num, item->level);
        }

        gpio_config_t io_conf = {
            .pin_bit_mask = (1ULL << item->gpio_num),
            .mode = item->mode,
            .pull_up_en = item->pull_up_en ? GPIO_PULLUP_ENABLE : GPIO_PULLUP_DISABLE,
            .pull_down_en = item->pull_down_en ? GPIO_PULLDOWN_ENABLE : GPIO_PULLDOWN_DISABLE,
            .intr_type = item->intr_type, // 仅配置中断类型，不做 ISR service 安装
        };

        esp_err_t err = gpio_config(&io_conf);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "gpio_config failed: index=%u gpio=%d err=%s",
                     (unsigned)i, (int)item->gpio_num, esp_err_to_name(err));
            return err;
        }

        // 若为输出（含 OD），设置初始电平
        if ((item->mode & GPIO_MODE_OUTPUT) != 0) {
            err = gpio_set_level(item->gpio_num, item->level);
            if (err != ESP_OK) {
                ESP_LOGE(TAG, "gpio_set_level failed: index=%u gpio=%d level=%d err=%s",
                         (unsigned)i, (int)item->gpio_num, item->level, esp_err_to_name(err));
                return err;
            }
        }

        ESP_LOGI(TAG,
                 "OK index=%u gpio=%d mode=%s PU=%d PD=%d intr=%d%s",
                 (unsigned)i,
                 (int)item->gpio_num,
                 mode_to_str(item->mode),
                 item->pull_up_en,
                 item->pull_down_en,
                 (int)item->intr_type,
                 ((item->mode & GPIO_MODE_OUTPUT) != 0) ? (item->level ? " level=1" : " level=0") : "");
    }

    return ESP_OK;
}
