#pragma once

#include <stdint.h>
#include "esp_err.h"
#include "u8g2.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化 0.96 寸 SSD1306 IIC OLED
 * @param sda GPIO
 * @param scl GPIO
 * @param addr_7bit IIC 地址（一般 0x3C）
 */
esp_err_t oled_iic_096_init(int sda, int scl, uint8_t addr_7bit, const uint8_t *font);

/**
 * @brief 获取 u8g2 句柄
 */
u8g2_t *oled_iic_096_get_u8g2(void);

/**
 * @brief 示例显示
 */
void oled_iic_096_demo(const char *text);

#ifdef __cplusplus
}
#endif
