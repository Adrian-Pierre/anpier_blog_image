#include "oled_iic_0.96.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

#include "u8g2_esp32_hal.h"

static const char *TAG = "oled_iic_096";

static u8g2_t g_u8g2;
static bool g_inited = false;

u8g2_t *oled_iic_096_get_u8g2(void)
{
    return g_inited ? &g_u8g2 : NULL;
}

esp_err_t oled_iic_096_init(int sda, int scl, uint8_t addr_7bit, const uint8_t *font)
{
    if (g_inited) {
        return ESP_OK;
    }

    vTaskDelay(pdMS_TO_TICKS(50));   // OLED 上电稳定

    u8g2_esp32_hal_t hal = U8G2_ESP32_HAL_DEFAULT;
    hal.bus.i2c.sda = sda;
    hal.bus.i2c.scl = scl;

    u8g2_esp32_hal_init(hal);

    // full buffer 模式（推荐）
    u8g2_Setup_ssd1306_i2c_128x64_noname_f(
        &g_u8g2,
        U8G2_R0,
        u8g2_esp32_i2c_byte_cb,
        u8g2_esp32_gpio_and_delay_cb
    );

    // u8g2 使用 8-bit IIC 地址
    u8x8_SetI2CAddress(&g_u8g2.u8x8, addr_7bit << 1);

    u8g2_InitDisplay(&g_u8g2);
    u8g2_SetPowerSave(&g_u8g2, 0);

    u8g2_ClearBuffer(&g_u8g2);

    if (font == NULL) {
        font = u8g2_font_ncenB10_tr;
    }
    
    u8g2_SetFont(&g_u8g2, font);
    u8g2_DrawStr(&g_u8g2, 0, 14, "OLED 0.96 Ready");
    u8g2_SendBuffer(&g_u8g2);

    g_inited = true;

    ESP_LOGI(TAG, "init ok (SDA=%d SCL=%d ADDR=0x%02X)",
             sda, scl, addr_7bit);

    return ESP_OK;
}

void oled_iic_096_demo(const char *text)
{
    u8g2_t *u8g2 = oled_iic_096_get_u8g2();

    u8g2_SetFont(u8g2, u8g2_font_ncenB10_tr); 

    int text_w = u8g2_GetStrWidth(u8g2, text);
    int ascent  = u8g2_GetAscent(u8g2);
    int descent = u8g2_GetDescent(u8g2);

    int x = 0;
    int y = ascent;
    int vx = 2;
    int vy = 1;

    while (1) {
        u8g2_ClearBuffer(u8g2);
        u8g2_DrawStr(u8g2, x, y, text);
        u8g2_SendBuffer(u8g2);

        x += vx;
        y += vy;

        /* X 边界检测 */
        if (x <= 0) {
            x = 0;
            vx = -vx;
        } else if (x >= (128 - text_w)) {
            x = 128 - text_w;
            vx = -vx;
        }

        /* Y 边界检测（baseline） */
        if (y <= ascent) {
            y = ascent;
            vy = -vy;
        } else if (y >= (64 + descent)) {
            y = 64 + descent;
            vy = -vy;
        }

        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
